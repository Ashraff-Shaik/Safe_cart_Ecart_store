import logo from '../../assets/images/logo.webp';
import { Twitter, Facebook, Instagram, GeoAlt, Phone, Envelope, Send } from 'react-bootstrap-icons';
import './footer.components.css';
export function Footer() {
    return (
        <div>
            <div className="card Foot  mt-5">
                <div className="row">
                    <div className="col-lg-3 col-md-2 col-sm-6 mt-5">
                        <img src={logo} />
                        <br></br>
                        <br></br>
                        <h6>The best multi-vendor ecommerce website for you. You can easily buy your product according to your choice.</h6>
                        <div className='Foicons'>
                            <p><Twitter></Twitter></p>
                            <p><Facebook></Facebook></p>
                            <p><Instagram></Instagram></p>
                        </div>
                    </div>
                    <div className='col-lg-3 col-md-2 col-sm-6 mt-5  Folinks'>
                        <ul >
                            <li>Helpful Links</li>
                            <li>Home</li>
                            <li>Blog</li>
                            <li>Contact</li>
                            <li>Shop page</li>
                        </ul>
                    </div>
                    <div className='col-lg-3 col-md-4 col-sm-6 mt-5 Fstore'>
                        <ul>
                            <li><h5>Store Info</h5></li>
                            <div className='Floc mt-2'>
                               <li> <GeoAlt></GeoAlt>
                                Dhaka,Bangladesh</li>
                            </div>
                            
                            <div className='Fcon mt-2'>
                               <li> <Phone></Phone>
                                0113213131322</li>
                            </div>
                        
                            <div className='Fsupp mt-2'>
                                <li><Envelope></Envelope>
                                support @safecart.com</li>
                            </div>
                        </ul>
                    </div>
                    <div className='col-lg-3 col-md-4 col-sm-6  mt-5 Fmail'>
                        <ul>
                        <li><h6>Get in Touch</h6></li>
                        <li>Sign up to your mail list now!</li>
                        <div>
                            <input type='text' placeholder='your mail here'></input>
                            <button><Send></Send></button>
                        </div>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    )
}