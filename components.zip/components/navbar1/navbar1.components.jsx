import {   GeoAlt,  Search } from "react-bootstrap-icons";
import  logo from '../../assets/images/logo.webp';
import { Link } from 'react-router-dom';
import './navbar1.components.css';
export function Navbar1() {
    return (
        <>
            
                <div className="container row navbar1 mt-2">
                    <div className="navlogo col-3">
                        <img src ={logo}></img>
                    </div>
                    <div className="col-3 navblock" >
                        <input type="text" placeholder="Search for Products" className="form-control"></input>
                        <button className="btn btn-success navbutton"><Search></Search></button>
                    </div>
                    <br></br>
                    <br></br>
                    <div className="col-3 block1">
                        <p><GeoAlt></GeoAlt></p>                  
                        <p><Link to ='/order' className='abli'>Order tracking</Link></p>
                    </div>
                </div>
                


        </>


    )
}