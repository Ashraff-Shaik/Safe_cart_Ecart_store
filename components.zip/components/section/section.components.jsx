import './section.components.css';
import product from '../../assets/images/product.png';
import product1 from '../../assets/images/product1.webp';
import product2 from '../../assets/images/product2.png';
import product3 from '../../assets/images/product3.webp';
import product4 from '../../assets/images/product4.webp';
import product5 from '../../assets/images/product5.webp';
import product6 from '../../assets/images/product6.webp';
import product7 from '../../assets/images/product7.webp';
import product8 from '../../assets/images/product8.webp';
import product9 from '../../assets/images/product9.webp';
import product10 from '../../assets/images/product10.webp';
import product11 from '../../assets/images/product11.webp';

import { ArrowRepeat, Heart } from 'react-bootstrap-icons';
export function Section() {
    return (
        <div>
            <div className="container sect  mt-5">
                <h3>Popular Products</h3>
                <h4>View all</h4>
            </div>
            <div className="row  mt-5">
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product' src={product3} />
                    <h6>TitanPro Gaming Laptop</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product4} />
                    <h6>GuardianEye HD Surveillance Camera</h6>
                    <h6>$140.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product5} />
                    <h6>SwiftGlide Precision Mouse</h6>
                    <h6>$1100.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product2' src={product6} />
                    <h6>Intle Gaming Laptop</h6>
                    <h6>$500.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
            </div>
            <div className="row ">
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product' src={product1} />
                    <h6>PhoenixTech Motherboard X7</h6>
                    <h6>$430.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product3} />
                    <h6>TitanPro Gaming Laptop</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product2} />
                    <h6>Yves Saint</h6>
                    <h6>$233.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product2' src={product7} />
                    <h6>UltraVision 4K Monitor</h6>
                    <h6>$500.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
            </div>
            <div className="row ">
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product' src={product8} />
                    <h6>Philosopy</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product9} />
                    <h6>Maison Francis</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product10} />
                    <h6>Dior</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product2' src={product11} />
                    <h6>Beardo</h6>
                    <h6>$500.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
            </div>

        </div>
    )
}