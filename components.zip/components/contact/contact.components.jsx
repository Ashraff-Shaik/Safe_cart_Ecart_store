import { Clock, Envelope, GeoAlt, Telephone } from "react-bootstrap-icons";
import { Navbar } from "../navbar/navbar.components";
import { Navbar1 } from "../navbar1/navbar1.components";
import { U_menu } from "../u_menu/u_menu.components";
import './contact.components.css';
import { Footer } from "../footer/footer.components";

export function Contact() {
    return (
        <div>
            <Navbar></Navbar>
            <Navbar1></Navbar1>
            <U_menu></U_menu>
            <div>
                <h2 style={{backgroundColor:'lightgray', padding:'3rem'}}>Contact</h2>
            </div>
            <div className="container">
                <div className="row">
                    <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3 cntcrd'>
                        <h2 className="mt-5">Contact with us</h2>
                        <div className="cntdt">
                            <div className="cnt mt-5" >
                                <div className="icon-box">
                                    <Telephone></Telephone>
                                </div>
                                <div >
                                    <h4 className="title" >Call us:</h4>
                                    <p className="info">+012 789654321</p>
                                </div>
                            </div>
                            <div className="cnt">
                                <Envelope></Envelope>
                                <div>
                                    <h4>Email Us:</h4>
                                    <p>company@mail.com</p>
                                </div>
                            </div>
                            <div className="cnt">
                                <Clock></Clock>
                                <div>
                                    <h4>Service Hour:</h4>
                                    <p>10.00 am to 8.00 pm</p>
                                </div>
                            </div>
                            <div className="cnt">
                                <GeoAlt></GeoAlt>
                                <div>
                                    <h4 >Address:</h4>
                                    <p >2779 Rubaiyat Road,
                                        <br></br>Traverse City,
                                        <br></br>MI 49684</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-lg-6 col-md-6 col-sm-12 col-xl-8 '>
                        <h4>Get In Touch</h4>
                        <div className="mt-5">
                            <p>Your name</p>
                            <input placeholder="your name" className="cntipt"></input>
                        </div>
                        <div className="mt-5">
                            <p>Your Email</p>
                            <input placeholder="your email" className="cntipt"></input>
                        </div>
                        <div className="mt-5">
                            <p>Your Subject</p>
                            <input placeholder="your subject" className="cntipt"></input>
                        </div>
                        <div className="mt-5">
                            <p>Your Message</p>
                            <input placeholder="your message" className="cntmsg" ></input>
                        </div>
                        <div className="mt-5">
                            <button style={{ backgroundColor: "darkgreen" }}>Submit</button>
                        </div>
                    </div>
                </div>
            </div>
            <Footer></Footer>
        </div>
    )
}