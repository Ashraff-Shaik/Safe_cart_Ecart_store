import product from '../../assets/images/product.png';
import product1 from '../../assets/images/product1.webp';
import product2 from '../../assets/images/product2.png';
import product12 from '../../assets/images/product12.webp';
import product13 from '../../assets/images/product13.webp';
import product14 from '../../assets/images/product14.webp';
import product15 from '../../assets/images/product15.webp';
import product16 from '../../assets/images/product16.webp';
import { ArrowRepeat, Heart } from 'react-bootstrap-icons';
import './product.components.css';

export function Product() {
    return (
        <div>
            <div className='container Tproduct mt-5'>
                <div>
                    <h2>Trending Products</h2>
                </div>
                <div>
                    <button className='btn btn-success '>Featured</button>
                    <button className='btn btn-success'>top selling</button>
                    <button className='btn btn-success'>weekly top</button>
                </div>
            </div>
            <div className='row mt-5 '>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product12} />
                    <h6>Mans Silver Ridge Lite Long Sleeve Shirt</h6>
                    <h6>$600.00</h6>
                    <div className='col-3 details'>
                        <button className='btn  btn-light '>View details</button>
                        <button className='btn btn-light btnn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn btn-light btnn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product13} />
                    <h6>High Heel Wedding Shoes</h6>
                    <h6>$400.00</h6>
                    <div className='col-3 details'>
                        <button className='btn  btn-light '>View details</button>
                        <button className='btn btn-light btnn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn btn-light btnn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product2' src={product14} />
                    <h6>Small Dining Table</h6>
                    <h6>$399.00</h6>
                    <div className='col-3 details'>
                        <button className='btn  btn-light '>View details</button>
                        <button className='btn btn-light btnn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn btn-light btnn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product' src={product1} />
                    <h6>PhoenixTech Motherboard X7</h6>
                    <h6>$430.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
            </div>
            <div className="row ">
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product' src={product1} />
                    <h6>PhoenixTech Motherboard X7</h6>
                    <h6>$430.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product15} />
                    <h6>TitanPro Gaming Laptop</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product2} />
                    <h6>Yves Saint</h6>
                    <h6>$233.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product2' src={product16} />
                    <h6>UltraVision 4K Monitor</h6>
                    <h6>$500.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
            </div>
        </div>


    )
}