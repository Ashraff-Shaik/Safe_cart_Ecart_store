import product1 from '../../assets/images/product1.webp';
import product2 from '../../assets/images/product2.png';
import hp1 from '../../assets/images/hp1.webp';
import hp2 from '../../assets/images/hp2.webp';
import hp3 from '../../assets/images/hp3.webp';
import hp4 from '../../assets/images/hp4.webp';
import hp5 from '../../assets/images/hp5.webp';
import hp6 from '../../assets/images/hp6.webp';
import product3 from '../../assets/images/product3.webp';
import product12 from '../../assets/images/product12.webp';
import product14 from '../../assets/images/product14.webp';
import product13 from '../../assets/images/product13.webp';
import product15 from '../../assets/images/product15.webp';
import hp9 from '../../assets/images/hp9.webp';

export function Home2() {
    return (
        <div>
            <div style={{backgroundColor:"black"}} id="carouselExampleControls" className="carousel slide" data-bs-ride="carousel">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src={hp1} className="d-block w-50" />
    </div>
    <div className="carousel-item">
      <img src={hp2} className="d-block w-50" />
    </div>
    <div className="carousel-item">
      <img src={hp3} className="d-block w-50" />
    </div>
  </div>
  <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Previous</span>
  </button>
  <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true"></span>
    <span className="visually-hidden">Next</span>
  </button>
</div>
            <div className='container mt-5 row'>
                <h2>Flash Sale</h2>
                <div style={{ margin: "2rem" }} className='card col-2'>
                    <img src={product3}></img>
                    <h6>TitanPro Gaming Laptop</h6>
                    <h6>$500</h6>
                    <del>$533</del>
                </div>
                <div style={{ margin: "2rem" }} className='card col-2'>
                    <img src={product1}></img>
                    <h6>Quantumcore pro gaming motherboard</h6>
                    <h6>$500</h6>
                    <del>$533</del>
                </div>
                <div style={{ margin: "2rem" }} className='card col-2'>
                    <img src={product2}></img>
                    <h6>Yves Saint</h6>
                    <h6>$500</h6>
                    <del>$533</del>
                </div>
                <div style={{ margin: "2rem" }} className='card col-2'>
                    <img src={product12}></img>
                    <h6>Mans Silver ridge long sleeves</h6>
                    <h6>$500</h6>
                    <del>$533</del>
                </div>
                <div style={{ margin: "2rem" }} className='card col-2'>
                    <img src={product14}></img>
                    <h6>Small Dining Table</h6>
                    <h6>$500</h6>
                    <del>$533</del>
                </div>
                <div style={{ margin: "2rem" }} className='card col-xl-2'>
                    <img src={product13}></img>
                    <h6>Long high heels</h6>
                    <h6>$500</h6>
                    <del>$533</del>
                </div>
                <div style={{ margin: "2rem" }} className='card col-xl-2'>
                    <img src={product15}></img>
                    <h6>Stylist Hall Chair</h6>
                    <h6>$500</h6>
                    <del>$533</del>
                </div>
                <div style={{ margin: "2rem" }} className='card col-xl-2'>
                    <img src={hp9}></img>
                    <h6>Stylist Hall Chair</h6>
                    <h6>$500</h6>
                    <del>$533</del>
                </div>
                

            </div>
        </div >
    )
}