import './navbar.components.css';
import { Twitter, Facebook, Instagram } from 'react-bootstrap-icons';
import { Link } from 'react-router-dom';
export function Navbar() {
    return (
        <div className='container-fluid contain'>
            <div className="contain1 col-3">
                <ul>
                    <li><Twitter></Twitter></li>
                    <li><Facebook></Facebook></li>
                    <li><Instagram></Instagram></li>
                </ul>
            </div>
            <div className='contain2 col-6'>
                <ul>
                    <li>Seller login</li>
                    <li><Link to ='/FAQ' className='Faqli'>FAQ</Link></li>
                    <li><Link to ='/Contact' className='Faqli'>Contact</Link></li>
                    <li>Tracking order</li>
                </ul>
            </div>
        </div>
    )
}