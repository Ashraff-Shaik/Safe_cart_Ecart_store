import './banners.components.css';
import banner from '../../assets/images/banner.webp';
import banner1 from '../../assets/images/banner1.webp';

export function Banners() {
    return (
        <>
            <div className="container totals">

                <div className='row bans'>
                    {/* <div className='col-6'> */}
                        <div className='container col-12 bans1'>
                            <div className='row'>
                                <div className='col-10   mt-5 bans1a'>
                                    <div className='col-5 mt-5 '>
                                        <h4 >November Gadget Madness </h4>
                                        <h3>20% off</h3>
                                        <button className='btn btn-warning'>GET Offer</button>
                                    </div>
                                    <div >
                                        <img className='Bsimg1 ' src={banner}></img>
                                    </div>
                                </div>
                            </div>
                        </div>
                    {/* </div> */}
                    {/* <div className='col-6'> */}
                        {/* <div className='container col-3 bans2 '>
                            <h3>Home Appliances Cyber Monday Special</h3>
                            <img src={banner1}></img>
                        </div> */}
                    {/* </div> */}
                </div>

                <div className=' container col-6  bans2 '>
                    <h3>Home Appliances Cyber Monday Special</h3>
                    <div>
                    <img className='Bsimg2' src={banner1}></img>
                    </div>
                </div>
            </div>
        </>
    )
}
