import './FAQ.components.css';
export function Faq(){
    return(
        <div>
           
            <div className=" error">
            <h1  >500</h1>
            <h3>Server error</h3>
            <p> please contact support</p>
            </div>
           
        </div>
    )
}