import logo1 from '../../assets/images/logo1.webp';
import logo1a from '../../assets/images/logo1a.webp';
import './section1.components.css';
export function Section1() {
    return (
        <div>
            <div className="container ">
                <div className='row'>
                    <div className="card col-2 mt-5 sect1log">
                        <div>
                        <img className='sect1img' src={logo1}></img>   
                        </div>
                        {/* <img className='sect1loga'src={logo1a}></img> */}
                        <div>
                        <h3>Loyce Hickle</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}