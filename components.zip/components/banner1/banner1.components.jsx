import person1 from '../../assets/images/person1.avif';
import './banner1.components.css';
export function Banner1() {
    return (
        <div>
            <div className="container lab mt-5 ">
                <div className='row'>
                    <div className='col-6 mt-5'>
                        <h5>Winter 2024 offer</h5>
                        <br></br>
                        <br></br>
                        <h1>Grab the best Fashion deals in this winter</h1>
                        <br></br>
                        <button className='btn btn-primary'>Get Deals</button>
                    </div>
                    <div className='col-6'>
                        <img className='B1img1' src={person1}></img>
                    </div>
                    
                </div>
            </div>
        </div>
    )
}