import { Calendar3, Tag } from 'react-bootstrap-icons';
import blog from '../../assets/images/blog.webp';
import blog1 from '../../assets/images/blog1.webp';
import blog2 from '../../assets/images/blog2.webp';
import blog3 from '../../assets/images/blog3.webp';
import blog4 from '../../assets/images/blog4.webp';
import blog5 from '../../assets/images/blog5.webp';
import './Blog.components.css';
import { Navbar } from '../navbar/navbar.components';
import { Navbar1 } from '../navbar1/navbar1.components';
import { U_menu } from '../u_menu/u_menu.components';
import { Footer } from '../footer/footer.components';
export function Blog() {
    return (
        <div>
            <Navbar></Navbar>
            <Navbar1></Navbar1>
            <U_menu></U_menu>
            <div >
                <h2 style={{backgroundColor:'lightgray', padding:'3rem'}}>Blog</h2>
            </div>
            <div className=" row mt-5 ">
                <div className="col-lg-6 col-md-6 col-sm-12 col-xl-4 ">
                    <div>
                        <img className='blgimg' src={blog}></img>
                    </div>
                    <div className='blgic mt-3'>
                        <div className='blgic1'>
                            <Calendar3></Calendar3> <p>Tue Jun 2020</p>
                        </div>
                        <div className='blgic1'>
                            <Tag></Tag> <p>Startup Bussiness</p>
                        </div>
                    </div>
                    <div>
                        <h4>New organization are added seal there</h4>
                        <p>Was drawing natural fat respect husband. An as noisy an offer drawn blush...</p>
                        <button className='rounded-pill blgbtn'>Read more</button>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 col-xl-4 mt-4 ">
                    <div>
                        <img className='blgimg1' src={blog1}></img>
                    </div>
                    <div className='blgic mt-3'>
                        <div className='blgic1'>
                            <Calendar3></Calendar3> <p>Fri Jun 2020</p>
                        </div>
                        <div className='blgic1'>
                            <Tag></Tag> <p>E-commerce</p>
                        </div>
                    </div>
                    <div>
                        <h4>Was drawing natural fat respect husband</h4>
                        <p>Was drawing natural fat respect husband. An as noisy an offer drawn blush...</p>
                        <button className='rounded-pill blgbtn'>Read more</button>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 col-xl-4">
                    <div>
                        <img className='blgimg' src={blog2}></img>
                    </div>
                    <div className='blgic mt-3'>
                        <div className='blgic1'>
                            <Calendar3></Calendar3> <p>Fri Jun 2020</p>
                        </div>
                        <div className='blgic1'>
                            <Tag></Tag> <p>E-commerce</p>
                        </div>
                    </div>
                    <div>
                        <h4>In mr began music weeks after at begin</h4>
                        <p>Was drawing natural fat respect husband. An as noisy an offer drawn blush...</p>
                        <button className='rounded-pill blgbtn'>Read more</button>
                    </div>
                </div>
            </div>
            <div className="row mt-5 ">
                <div className="col-lg-6 col-md-6 col-sm-12 col-xl-4 ">
                    <div>
                        <img className='blgimg' src={blog3}></img>
                    </div>
                    <div className='blgic mt-3'>
                        <div className='blgic1'>
                            <Calendar3></Calendar3> <p>Sun Jun 2020</p>
                        </div>
                        <div className='blgic1'>
                            <Tag></Tag> <p>Digital marketing</p>
                        </div>
                    </div>
                    <div>
                        <h4>Travelling every thing her eat simply</h4>
                        <p>Was drawing natural fat respect husband. An as noisy an offer drawn blush...</p>
                        <button className='rounded-pill blgbtn'>Read more</button>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 col-xl-4 ">
                    <div>
                        <img className='blgimg' src={blog5}></img>
                    </div>
                    <div className='blgic mt-3'>
                        <div className='blgic1'>
                            <Calendar3></Calendar3> <p>Mon Jun 2020</p>
                        </div>
                        <div className='blgic1'>
                            <Tag></Tag> <p>E-commerce</p>
                        </div>
                    </div>
                    <div>
                        <h4>These tried for way joy wrote <br></br> witty</h4>
                        <p>Was drawing natural fat respect husband. An as noisy an offer drawn blush...</p>
                        <button className='rounded-pill blgbtn'>Read more</button>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-12 col-xl-4">
                    <div>
                        <img className='blgimg' src={blog5}></img>
                    </div>
                    <div className='blgic mt-3'>
                        <div className='blgic1'>
                            <Calendar3></Calendar3> <p>Sun Jun 2020</p>
                        </div>
                        <div className='blgic1'>
                            <Tag></Tag> <p>E-commerce</p>
                        </div>
                    </div>
                    <div>
                        <h4>THEY SAY A PICTURE SPEAKS A THOUSAND WORDS, RIGHT?</h4>
                        <p>Was drawing natural fat respect husband. An as noisy an offer drawn blush...</p>
                        <button className='rounded-pill blgbtn'>Read more</button>
                    </div>
                </div>
            </div>
            <div className="row mt-5 ">
                <div className="col-lg-6 col-md-6 col-sm-12 col-xl-4 ">
                    <div>
                        <img className='blgimg' src={blog3}></img>
                    </div>
                    <div className='blgic mt-3'>
                        <div className='blgic1'>
                            <Calendar3></Calendar3> <p>Sun Jun 2020</p>
                        </div>
                        <div className='blgic1'>
                            <Tag></Tag> <p>Digital marketing</p>
                        </div>
                    </div>
                    <div>
                        <h4>Travelling every thing her eat simply</h4>
                        <p>Was drawing natural fat respect husband. An as noisy an offer drawn blush...</p>
                        <button className='rounded-pill blgbtn'>Read more</button>
                    </div>
                </div>
            </div>
            <Footer></Footer>
        </div>
    )
}