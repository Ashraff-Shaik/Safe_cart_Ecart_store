import icon4 from '../../assets/images/icon4.svg';
import icon5 from '../../assets/images/icon5.svg';
import icon6 from '../../assets/images/icon6.svg';


export function Block1() {
    return (
        <div>
            <br></br>
            <br></br>
            <div className="container">
                <div className='row'>
                    <div className='col-4 mt-5 icon'>
                        <img src={icon4}></img>
                        <div>
                        <h6>Secure Payments Gateway</h6>
                        <p>Partnered with 48+ gateways for your safety</p>
                        </div>
                        </div>
                        
                    <div className='col-4 mt-5 icon'>
                        <img src={icon5}></img>
                        <div>
                        <h6>Customer Reviews</h6>
                        <p>Verified reviews are featured in our platforms</p>
                        </div>
                        </div>
                        
                    
                    <div className='col-4 mt-5 icon'>
                        <img src={icon6}></img>
                        <div>
                        <h6>30 Day No-Hassle Return</h6>
                        <p>We guarantee happiness, If you're not return it</p>
                        </div>
                    </div>
                </div>
                

            </div>
        </div>
    )
}