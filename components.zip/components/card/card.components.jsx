
import React from "react";


export class CardComponents extends React.Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    render() {
        return (
            <div className="chat">
                <div className="card-header">
                
                </div>
                
            </div>
        )
    }
}