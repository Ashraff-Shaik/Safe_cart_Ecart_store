import person from '../../assets/images/person.jpg';

export function Flex() {
    return (
        <div>
            <div className="image-flex">
                <h5>Details</h5>
                <img src={person} />
                <div>
                    <h6>Name:Ash</h6>
                    <h6>DOB:30/08/2001</h6>
                </div>
            </div>
        </div>
    )
}