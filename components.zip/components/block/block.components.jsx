import icon from '../../assets/images/icon.svg';
import icon1 from '../../assets/images/icon1.svg';
import icon2 from '../../assets/images/icon2.svg';
import icon3 from '../../assets/images/icon3.svg';
import './block.components.css';
export function Block() {
    return (
        <div>
            <br></br>
            <br></br>
            <div className="container block">
                <div className='row'>
                    <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                        <img src={icon}></img>
                        <div>
                            <h6>Secure Payments Gateway</h6>
                            <p>Partnered with 48+ gateways for your safety</p>
                        </div>
                    </div>

                    <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                        <img src={icon1}></img>
                        <div>
                            <h6>Customer Reviews</h6>
                            <p>Verified reviews are featured in our platforms</p>
                        </div>
                    </div>


                    <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                        <img src={icon2}></img>
                        <div>
                            <h6>30 Day No-Hassle Return</h6>
                            <p>We guarantee happiness, If you're not return it</p>
                        </div>
                    </div>

                    <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                        <img src={icon3}></img>
                        <div>
                            <h6>30 Day No-Hassle Return</h6>
                            <p>We guarantee happiness, If you're not return it</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}