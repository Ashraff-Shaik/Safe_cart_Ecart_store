import product from '../../assets/images/product.png';
import product1 from '../../assets/images/product1.webp';
import product2 from '../../assets/images/product2.png';
import product8 from '../../assets/images/product8.webp'
import product9 from '../../assets/images/product9.webp'
import product10 from '../../assets/images/product10.webp'
import product11 from '../../assets/images/product11.webp'
import { ArrowRepeat, Heart } from 'react-bootstrap-icons';

export function Product1() {
    return (
        <div>
            <div className='Tproduct1 mt-5'>
                <div>
                    <h2>Categories</h2>
                </div>
                <div>
                    <button className='btn btn-success btn:hover'>Featured</button>
                    <button className='btn btn-success'>top selling</button>
                    <button className='btn btn-success'>weekly top</button>
                </div>
            </div>
            <div className='row'>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3' >
                    <img className='product1' src={product1} />
                    <h6>ali</h6>
                    <h6>$110</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product1} />
                    <h6>ali</h6>
                    <h6>$110</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product2' src={product2} />
                    <h6></h6>
                    <h6></h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product9} />
                    <h6>Maison Francis</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
            </div>
            
            <div className="row">
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3' >
                    <img className='product' src={product8} />
                    <h6>Philosopy</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product9} />
                    <h6>Maison Francis</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product1' src={product10} />
                    <h6>Dior</h6>
                    <h6>$110.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
                <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                    <img className='product2' src={product11} />
                    <h6>Beardo</h6>
                    <h6>$500.00</h6>
                    <div className='col-3 details'>
                        <button className='btn '>View details</button>
                        <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                        <button className='btn'><Heart></Heart></button>
                    </div>
                </div>
        </div>
        </div>
    )
}