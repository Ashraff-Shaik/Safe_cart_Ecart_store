import { Check2 } from 'react-bootstrap-icons';
import person2 from '../../assets/images/person2.webp';
import person3 from '../../assets/images/person3.webp';
import person4 from '../../assets/images/person4.webp'
import './banner2.components.css';

export function Banner2() {
    return (
        <div>
            <br>
            </br>
            <br></br>
            <div className="container total">
                <div className=' container ban21'>
                    <div className='container row ban21i'>
                        <div className='col-6 mt-5'>
                            <h2>Winter <br></br>ON the Door </h2>
                            <br></br>
                            <br></br>
                            <div className='ban3i'>
                                <h4><Check2></Check2></h4>
                                <h4>Skin care</h4>
                            </div>
                            <div className='ban3i'>
                                <h4><Check2></Check2></h4>
                                <h4>Fashion Wear</h4>
                            </div>
                            <div className='ban3i'>
                                <h4><Check2></Check2></h4>
                                <h4>Electronic Items</h4>
                            </div>
                            <div className='ban3i'>
                                <h4><Check2></Check2></h4>
                                <h4>Furniture</h4>
                            </div>
                            <br>
                            </br>
                            <br></br>
                            <button className='btn btn-primary'>GET Offer</button>
                        </div>
                        <div className='col-6 mt-5 ban3p'>
                            <img className='B2img1 ' src={person2}></img>
                        </div>
                    </div>
                </div>
                <div>

                    <div className='container row ban3'>
                        <div className='col-6 mt-5'>
                            <h3>ENJOY YOUR TEXAS STYLE WINTER FASHION 2023 </h3>
                            <br></br>


                            <button className='btn btn-primary'>GET Offer</button>
                        </div>
                        <div className='col-6'>
                            <img className='img-B2 ' src={person3}></img>
                        </div>
                    </div>

                    <br></br>
                    <div className=' row  ban4'>
                        <div className='col-lg-6 col-md-6 col-sm-12 col-xl-6'>
                            <img className='img ' src={person4}></img>
                        </div>
                        <div className='col-lg-6 col-md-6 col-sm-12 col-xl-6'>
                            <h3>NAILS CARE?GET YOUR WINTER KIT NOW </h3>
                            <br></br>                            
                            <button className='btn btn-dark'>GET Offer</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    )
}