import { Navbar } from '../navbar/navbar.components';
import { Navbar1 } from '../navbar1/navbar1.components';
import { U_menu } from '../u_menu/u_menu.components';
import { Footer } from '../footer/footer.components';
import product1 from '../../assets/images/product1.webp';
import product2 from '../../assets/images/product2.png';
import product3 from '../../assets/images/product3.webp';
import product4 from '../../assets/images/product4.webp';
import product5 from '../../assets/images/product5.webp';
import product6 from '../../assets/images/product6.webp';
import product7 from '../../assets/images/product7.webp';
import product8 from '../../assets/images/product8.webp';
import product13 from '../../assets/images/product13.webp';
import product14 from '../../assets/images/product14.webp';
import product15 from '../../assets/images/product15.webp';
import product16 from '../../assets/images/product16.webp';
import product17 from '../../assets/images/product17.webp';
import product18 from '../../assets/images/product18.webp';
import product9 from '../../assets/images/product9.webp';

import { App, ArrowRepeat, BorderAll, Heart, List, Plus, SquareFill, Star, StarFill } from 'react-bootstrap-icons';
import './Productpg.components.css';
export function Productpg() {
    return (
        <div>
            <Navbar></Navbar>
            <Navbar1></Navbar1>
            <U_menu></U_menu>
            <div className='container m-2' style={{ backgroundColor: 'lightgray', padding: '3rem' }}>
                <h1>Products</h1>
                <p>Shop page</p>
            </div>
            <div className="container  ">
                <div className=' row'>
                    <div className=' container col-8'>
                        <div className='prodlst mt-5'>
                            <div className='prodlsticon'>
                                <List></List>
                                <BorderAll></BorderAll>
                            </div>
                            <div className='prodlstitm'>
                                <p>Showing 1-16 of 136 results</p>
                                <input placeholder='order by asc'></input>
                            </div>
                        </div>
                        <div className='row  mt-5'>

                            <div className='col-lg-6 col-md-6 col-sm-6 col-xl-3'>
                                <img className='Pgproduct' src={product3}></img>
                                <h6 className='card limit1'>-6%</h6>
                                <h6 className='card limit'>Limited</h6>
                                <h6>TitanPro Gaming Laptop</h6>
                                <div className='pgproddt'>
                                    <h6>$110.00</h6>
                                    <del>$145.00</del>
                                </div>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>
                                {/* <div className='pgproddt'>
                                    <button className='btn '>View details</button>
                                    <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                                    <button className='btn'><Heart></Heart></button>
                                </div> */}
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product4}></img>
                                <h6>GuardianEye HD Surveillance Camera</h6>
                                <div className='pgproddt'>
                                    <h6>$230.00</h6>
                                    <del>$375.00</del>
                                </div>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product5}></img>
                                <h6 className='card limit1'>-57%</h6>
                                <h6>SwiftGlide Precision Mouse</h6>
                                <div className='pgproddt'>
                                    <h6>$210.00</h6>
                                    <del>$245.00</del>
                                </div>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>
                                {/* <div className='pgproddt'>
                                    <button className='btn '>View details</button>
                                    <button className='btn'><ArrowRepeat></ArrowRepeat></button>
                                    <button className='btn'><Heart></Heart></button>
                                </div> */}
                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product6}></img>
                                <h6 className='card limit1'>-17%</h6>
                                <h6>Intle Gaming Laptop</h6>
                                <div className='pgproddt'>
                                    <h6>$610.00</h6>
                                    <del>$845.00</del>
                                </div>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                        </div>

                        <br></br>
                        <div className='row mt-5'>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product1}></img>
                                <h6>PhoenixTech Motherboard X7</h6>
                                <div className='pgproddt'>
                                    <h6>$310.00</h6>
                                    <del>$445.00</del>
                                </div>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product2}></img>
                                <h6>Yves Saint</h6>
                                <div className='pgproddt'>
                                    <h6>$210.00</h6>
                                    <del>$345.00</del>
                                </div>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product7}></img>
                                <h6 className='card limit'>Limited</h6>
                                <h6>UltraVision 4K Monitor</h6>
                                <div className='pgproddt'>
                                    <h6>$710.00</h6>
                                    <del>$995.00</del>
                                </div>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product8}></img>
                                <h6>Philosopy</h6>
                                <div className='pgproddt'>
                                    <h6>$50.00</h6>
                                    <del>$75.00</del>
                                </div>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                        </div>
                        <br></br>
                        <div className='row mt-5'>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product17}></img>
                                <h6 className='card arrival'>New Arrival</h6>
                                <h6>Channel</h6>
                                <div className='pgproddt'>
                                    <h6>$55.00</h6>
                                    <del>$87.00</del>
                                </div>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product18}></img>
                                <h6>Daisy</h6>
                                <div className='pgproddt'>
                                    <h6>$80.00</h6>
                                    <del>$115.00</del>
                                </div>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product8}></img>
                                <h6 className='card arrival'>New Arrival</h6>
                                <h6>Philosophy</h6>
                                <div className='pgproddt'>
                                    <h6>$75.00</h6>
                                    <del>$95.00</del>
                                </div>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product9}></img>
                                <h6>Dior</h6>
                                <div className='pgproddt'>
                                    <h6>$75.00</h6>
                                    <del>$95.00</del>
                                </div>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (101)</h6>

                            </div>
                        </div>
                        <br></br>
                        <div className='row mt-5'>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product13}></img>
                                <h6 className='card arrival'>New Arrival</h6>
                                <h6>High Heel Wedding Shoes</h6>
                                <div className='pgproddt'>
                                    <h6>$110.00</h6>
                                    <del>$145.00</del>
                                </div>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (122)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product14}></img>
                                <h6 className='card limit1'>-57%</h6>
                                <h6>Small Dining Table</h6>
                                <div className='pgproddt'>
                                    <h6>$110.00</h6>
                                    <del>$145.00</del>
                                </div>
                                <br></br>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (198)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product15}></img>
                                <h6 className='card limit1'>-17%</h6>
                                <h6>stylish Hall Room Chair</h6>
                                <div className='pgproddt'>
                                    <h6>$110.00</h6>
                                    <del>$145.00</del>
                                </div>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (989)</h6>

                            </div>
                            <div className='col-lg-6 col-md-6 col-sm-12 col-xl-3'>
                                <img className='Pgproduct' src={product16}></img>
                                <h6>Yves Saint Shirt</h6>
                                <div className='pgproddt'>
                                    <h6>$110.00</h6>
                                    <del>$145.00</del>
                                </div>
                                <br></br>
                                <br></br>
                                <h6 style={{ color: 'darkgreen' }}>Stock Availability (50)</h6>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div className='card mt-5 prodpgbkl'>
                            <ul className='container'><h3>Categories</h3>
                                <br></br>
                                <div className='prodpgblk'>
                                    <p>Electronics </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p>Fashion & living </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p>Gardening & outdoors </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p> Sports & Fitness </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p>Personal care & beauty </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p>Kid & Babies </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p>Music & Instruments </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p>Automotive & Vehicles </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p>Arts & Crafts </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p> Health & Wellness </p>
                                    <Plus></Plus>
                                </div>
                                <div className='prodpgblk'>
                                    <p>Pets & Animal suppiles </p>
                                    <Plus></Plus>
                                </div>

                                <div className='prodpgblk'>
                                    <p>Books & literature </p>
                                    <Plus></Plus>
                                </div>
                            </ul>
                        </div>
                        <div className='card  mt-5 prodpgbkl '>
                            <ul><h3>Filter by rating</h3></ul>
                            <div className='star'>
                                <p><StarFill></StarFill><StarFill></StarFill><StarFill></StarFill><StarFill></StarFill><StarFill></StarFill></p>
                                <p><StarFill></StarFill><StarFill></StarFill><StarFill></StarFill><StarFill></StarFill><Star></Star></p>
                                <p><StarFill></StarFill><StarFill></StarFill><StarFill></StarFill><Star></Star><Star></Star></p>
                                <p><StarFill></StarFill><StarFill></StarFill><Star></Star><Star></Star><Star></Star></p>
                                <p><StarFill></StarFill><Star></Star><Star></Star><Star></Star><Star></Star></p>
                                <br></br>
                            </div>
                        </div>
                        <div className='card mt-5 prodpgbkl'>
                            <ul className='container' ><h3>Brands</h3>
                                <div className='prodpgblk1'>
                                    <App></App>
                                    <p>Nike </p>
                                </div>
                                <div className='prodpgblk1'>
                                    <App></App>
                                    <p>Ikea </p>
                                </div>
                                <div className='prodpgblk1'>
                                    <App></App>
                                    <p>Samsung </p>
                                </div>
                                <div className='prodpgblk1'>
                                    <App></App>
                                    <p>Apple </p>
                                </div>
                                <div className='prodpgblk1'>
                                    <App></App>
                                    <p>Ecopure </p>
                                </div>
                            </ul>
                        </div>
                        <div className='card mt-5 prodpgbkl'>
                            <h3>Size</h3>
                            <ul className='container prodpgblk2 '>
                                <li className='card '>
                                    Medium
                                </li>
                                <li className='card'>
                                    Large
                                </li>
                                <div className='card'>
                                    Small
                                </div>
                            </ul>
                        </div>
                        <div className='card mt-5 prodpgbkl'>
                            <h3>Colors</h3>
                            <ul className='container prodpgblk2'>
                                <li className='prodcoloricon'>
                                    <SquareFill></SquareFill>
                                </li>
                                <li >
                                    <SquareFill></SquareFill>
                                </li>
                                <li className='prodcoloricon1'>
                                    <SquareFill></SquareFill>
                                </li>
                                <li className='prodcoloricon2'>
                                    <SquareFill></SquareFill>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <Footer></Footer>
        </div >
    )
}