import React from "react" ;
import { Navbar } from "../navbar/navbar.components";
import { U_menu } from "../u_menu/u_menu.components";
import { Banners } from "../banners/banners.components";
import { Banner1 } from "../banner1/banner1.components";
import { Section } from "../section/section.components";
import { Block } from "../block/block.components";
import { Product } from "../product/product.components";
import { Banner2 } from "../banner2/banner2.components";
import { Product1 } from "../product1/product1.components";
import { Block1 } from "../block1/block1.components";
import { Footer } from "../footer/footer.components";
import { Navbar1 } from "../navbar1/navbar1.components";
export const Home=()=>{
    return(
        <div>
             <Navbar></Navbar>
             <Navbar1></Navbar1>
             <U_menu></U_menu>
             <Banners></Banners>
             <Banner1></Banner1>
             <Section></Section>
             <Block></Block>
             <Product></Product>
             <Banner2></Banner2>
             <Product1></Product1>
             <Block1></Block1>
             <Footer></Footer> 

             
        </div>
    )

}