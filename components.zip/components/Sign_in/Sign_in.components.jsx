import { Facebook, Google } from 'react-bootstrap-icons';
import './Sign_in.components.css';
import { Navbar } from '../navbar/navbar.components';
import { Navbar1 } from '../navbar1/navbar1.components';
import { U_menu } from '../u_menu/u_menu.components';
import { Footer } from '../footer/footer.components';
export function Signin() {
    return (
        <div>
            <Navbar></Navbar>
            <Navbar1></Navbar1>
            <U_menu></U_menu>
            <div>
                <h2 style={{ backgroundColor: 'lightgray', padding: '3rem' }}>Sign In</h2>
            </div>
            <div className="container mt-5 row ">
                <div className="col-xl-6 col-lg-6 col-sm-3 col-md-6 card sicard" style={{ width: '40%', padding:'1rem'}}>
                    {/* <h3>Sign In </h3> */}
                    <div className='sidt' >
                        <h3>Sign In </h3>
                        <br></br>
                        <p style={{ fontWeight: "bold" }}>Email or Username</p>
                        <input placeholder="test_user" className='sipt' ></input>
                        <p style={{ fontWeight: "bold" }}>Password</p>
                        <input placeholder="....." className='sipt'></input>
                    </div>
                    <div className='mt-2'>
                        <button style={{ width: "100%", backgroundColor: "green" }}>Sign In</button>
                    </div>
                    <div className='row mt-2'>
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                            <label class="form-check-label" for="flexCheckDefault">
                                Remember me
                            </label>
                        </div>
                        <div className='col-6'>
                            <p>Forgot Password</p>
                        </div>
                    </div>
                        <div className='orcnt '>
                            <span><center>Or</center></span>
                        </div>
                            <div className='sigoo mt-3' >
                              <span ><Google></Google>Login with google</span> &nbsp;&nbsp;  &nbsp;                          
                              <span><Facebook></Facebook> Login with facebook</span> 
                            </div>                   
                </div>
            </div>
           <Footer></Footer>
        </div>

    )
}