export function Grid() {
    // let headers = {
    //     h1: "S.no",
    //     h2: "Name",
    //     h3: "email",
    //}
    let headers;
    headers = new Object({
        h1: "S.No",
        h2: "Name"
    });

    let employee = ["ash", "Bash"]
    // let employees1 = new Array(1,2);


    let employee1 = { id: 2, name: "Hany", email: "H@gmail" };
    let employee2 = { id: 3, name: "Abdul", email: "A@gmail" };
    let employee3 = { id: 4, name: "Saif", email: "S@gmail" };
    let employees = [employee1, employee2, employee3]

    //push - push element at last index position
    employees.push(
        {
            id: 5,
            name: "Izaan",
            email: "I@gmail",
        }
    );
    //Unshift - add element at the first index position
    employees.unshift(
        {
            id: 1,
            name: "Siraj",
            email: "S@gmail"
        }
    );


    return (
        <div>
            <table className="table table-bordered">
                <thead>
                    <tr>
                        <td>{headers.h1}</td>
                        <td>{headers.h2}</td>
                        <td>Email</td>
                    </tr>
                </thead>
                <tbody>
                    {/* creating array */}
                    {/* <tr>
                        <td>0</td>
                        <td>{employee[0]}</td>
                        <td>R@gmail</td>
                    </tr>
                    
                    {/* <tr>
                        <td>{employees[0].id}</td>
                        <td>{employees[0].name}</td>
                        <td>{employees[0].email}</td>
                    </tr>
                    <tr>
                        <td>{employees[1].id}</td>
                        <td>{employees[1].name}</td>
                        <td>{employees[1].email}</td>
                    </tr>
                    <tr>
                        <td>{employees[2].id}</td>
                        <td>{employees[2].name}</td>
                        <td>{employees[2].email}</td>
                    </tr> */} 
                {
                    // employees.map(employeeData)
                    employees.map((item,index,array)=>{
                        return(
                            <tr>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.email}</td>
                            </tr>
                        )
                    }
                    )
                }
                </tbody>
            </table>
        </div>
    )
};
// const employeeData= function(item, index,arr){
//     return(
//         <tr>
//             <td>{item.id}</td>
//             <td>{item.name}</td>
//             <td>{item.email}</td>
//         </tr>
//     )
// }