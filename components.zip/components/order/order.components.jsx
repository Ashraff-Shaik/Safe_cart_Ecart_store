import order from '../../assets/images/order.webp';
import { Footer } from '../footer/footer.components';
import { Navbar } from '../navbar/navbar.components';
import { Navbar1 } from '../navbar1/navbar1.components';
import { U_menu } from '../u_menu/u_menu.components';
import './order.components.css';
export function Order() {
    return (
        <div>
            <Navbar></Navbar>
            <Navbar1></Navbar1>
            <U_menu></U_menu>
            <div>
                <h2 style={{ backgroundColor: 'lightgray', padding: '3rem' }}>Track order</h2>
            </div>
            <div className="container mt-5">
                <div className="row">
                    <div className="col-xl-6">
                        <div className='card ordercd'>
                            <h4>Order tracking</h4>
                            <div className='mt-2'>
                                <h6>Order Id</h6>
                                <input placeholder='order id'></input>
                            </div>
                            <div className='mt-2'>
                                <h6>Email</h6>
                                <input placeholder='Billing Email'></input>
                            </div>
                            <div className='mt-3'>
                                <button>Track your order</button>
                            </div>

                        </div>
                    </div>
                    {/* <div className="col-xl-6">
                        <img className="orderimg" src={order}></img>
                    </div> */}
                    <img className="orderimg" src={order}></img>

                </div>

            </div>
            <Footer></Footer>
        </div>
    )
}