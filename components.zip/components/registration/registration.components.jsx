import './registration.component.css'

export function RegistrationPage() {
    //logic//
    return (
        //jsx//

        // <div className='RTable'>
        //    <div >
        //         <table className='table table-bordered table-hover'>
        //             <thead className=''>
        //                 <tr class="table-primary">
        //                     <th>S.no</th>
        //                     <th>Name</th>
        //                     <th>Email</th>
        //                     <th>Phone</th>
        //                 </tr >
        //             </thead>
        //             <tbody>
        //                 <tr class="table-info">
        //                     <td>1</td>
        //                     <td>Suresh</td>
        //                     <td>S@gmail</td>
        //                     <td>1234</td>

        //                 </tr>
        //                 <tr class="table-success">
        //                     <td>2</td>
        //                     <td>Ramesh</td>
        //                     <td>R@gmail</td>
        //                     <td>5678</td>
        //                 </tr>
        //                 <tr class="table-warning">
        //                     <td>3</td>
        //                     <td>Rahim</td>
        //                     <td>Ra@gmail</td>
        //                     <td>7890</td>
        //                 </tr>
        //                 <tr class="table-active">
        //                     <td>4</td>
        //                     <td>Ashraff</td>
        //                     <td>As@gmail</td>
        //                     <td>1296</td>
        //                 </tr>
        //                 <tr class="table-dark">
        //                     <td>5</td>
        //                     <td>Naveed</td>
        //                     <td>Na@gmail</td>
        //                     <td>6789</td>
        //                 </tr>
        //             </tbody>
        //         </table>
        //         <div className='button'>
        //             <input type='button' value='save' className='btn btn-primary '></input>
        //             <div class='Toast-show'>
        //                 <div class='toast-header'>
        //                     <strong class="me-auto">SignIn</strong>
        //                     <button type='button' class='btn-close' data-bs-dismiss="toast"></button>
        //                 </div>
        //                 <div class='toast-body'>
        //                     <p>signup if already has a account</p>
        //                 </div>
        //             </div>
        //         </div>
        //         <nav class="navbar bg-light">
        //             <div class="container-fluid">
        //                 <ul class="navbar-nav">
        //                     <li class="nav-item">
        //                         <a class="nav-link" href="#">Link 1</a>
        //                     </li>
        //                     <li class="nav-item">
        //                         <a class="nav-link" href="#">Link 2</a>
        //                     </li>
        //                     <li class="nav-item">
        //                         <a class="nav-link" href="#">Link 3</a>
        //                     </li>
        //                 </ul>
        //             </div>
        //         </nav>
        //         <div class="container-fluid mt-3">
        //             <h3>PRACTISE (Vertical Navbar Example)</h3>
        //             <p>A navigation bar is a navigation header that is placed at the top of the page.</p>
        //         </div>
        //         <br></br>
        //         <br></br>
        //         <br></br>
        //         <div class="container mt-3">
        //             <h2>PRACTISE (Select Menu)</h2>
        //             <p>To style a select menu in Bootstrap 5, add the .form-select class to the select element:</p>
        //             <form action="/action_page.php">
        //                 <label for="sel1" class="form-label">Select list (select one):</label>
        //                 <select class="form-select" id="sel1" name="sellist1">
        //                     <option>1</option>
        //                     <option>2</option>
        //                     <option>3</option>
        //                     <option>4</option>
        //                 </select>
        //                 <br></br>

        //                 <label for="sel2" class="form-label">Mutiple select list (hold shift to select more than one):</label>
        //                 <select multiple class="form-select" id="sel2" name="sellist2">
        //                     <option>1</option>
        //                     <option>2</option>
        //                     <option>3</option>
        //                     <option>4</option>
        //                     <option>5</option>
        //                 </select>
        //                 <button type="submit" class="btn btn-primary mt-3">Submit</button>
        //             </form>
        //         </div>
        //         <br></br>
        //         <br></br>
        //         <br></br>
        //         <br></br>

        //         <div class="container mt-3">
        //             <h3>PRACTISE (Input Group Buttons)</h3>

        //             <div class="input-group mb-3 mt-3">
        //                 <button class="btn btn-outline-primary" type="button">Basic Button</button>
        //                 <input type="text" class="form-control" placeholder="Some text"></input>
        //             </div>

        //             <div class="input-group mb-3">
        //                 <input type="text" class="form-control" placeholder="Search"></input>
        //                     <button class="btn btn-success" type="submit">Go</button>
        //             </div>

        //             <div class="input-group mb-3">
        //                 <input type="text" class="form-control" placeholder="Something clever.."></input>
        //                     <button class="btn btn-primary" type="button">OK</button>
        //                     <button class="btn btn-danger" type="button">Cancel</button>
        //             </div>
        //         </div>

        //     </div>
        //     {/* <img class="image-fluid" src='https://ceblog.s3.amazonaws.com/wp-content/uploads/2017/09/19114623/forms.png'></img> */}
        // </div>







        <div>
            <div className="register">
                <h3>Registration</h3>
                <div className='row p-2'>
                    <div className='col-xl-6 col-sm-12'>
                        <label>First Name</label>
                        <input type="text" placeholder="first name" className="form-control"></input>
                    </div>
                    <div className='col-xl-6 col-sm-12'>
                        <label>Last name</label>
                        <input type="text" placeholder="last name" className='form-control'></input>
                    </div>
                </div>
                <div className='row p-2'>
                    <div className='col-xl-6 col-sm-12'>
                        <label>Email</label>
                        <input type="text" placeholder="email" className="form-control"></input>
                    </div>
                    <div className='col-xl-6 col-sm-12'>
                        <label>Phone</label>
                        <input type="number" placeholder="number" className='form-control'></input>
                    </div>
                </div>
                <div className='gender' >
                    <div className='row'>
                        <div className='col-5'>
                            <h6>Gender</h6>
                            <input type="radio" value='male' /> <label>Male  </label>&nbsp;
                            <input type='radio' value='female' /> <label>  Female</label>&nbsp;
                            <input type='radio' value='others' /> <label>Others</label> &nbsp;
                        </div>
                    </div>
                </div>
                <div >
                    <input type='button' value='Register' className='btn btn-primary' />
                </div>
            </div>
        </div >
    )
}