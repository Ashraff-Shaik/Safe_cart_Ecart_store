import { Link } from 'react-router-dom';
import './menu.components.css';
export function Menu(){
    return(
    <div>
        <ul className="menu">
            <li className="menu-list">Home
                <ul className='sub-menu'>
                    <li><Link to='https://www.amazon.in/gp/help/customer/display.html?nodeId=200507590&ref_=footer_gw_m_b_he'> Terms&Conditions</Link></li>
                    <li>Contact us</li>
                    <li>Privacy Policy</li>
                </ul>
            </li>
            <li className="menu-list">About us
            <ul className='sub-menu1'>
                <li>Most liked</li>
                <li>Best Gift</li>
                <li>Movers and shakers</li>
            </ul>
            </li>
            <li className="menu-list">Best sellers</li>
            <li className="menu-list">Today's deals</li>
            <li className="menu-list">Customer Service</li>

        </ul>
    </div>
    )
}