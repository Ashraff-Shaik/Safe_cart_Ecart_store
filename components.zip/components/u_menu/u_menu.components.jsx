import './u_menu.components.css';
import { Heart, Cart, Person, ChevronDown } from 'react-bootstrap-icons';
import { Link } from 'react-router-dom';

export function U_menu() {
    return (
        <div>
            <div className='container menu1'>
                <ul className="menu">
                    <li className="Hmenu">Home pages <ChevronDown></ChevronDown>
                        <ul className='Hsmenu'>
                            <li><Link to='/home'className='abli'>Home Style 1</Link></li>
                            <li><Link to='/home2'className='abli'>Home Style 2</Link></li>
                            <li>Home Style 3</li>
                        </ul>
                    </li>
                    <li><Link to='/About' className='abli'>About</Link></li>
                    <li className='Hmenu'>Shop page<ChevronDown></ChevronDown>
                        <ul className='Hsmenu'>
                            <li><Link to='/Productpg' className='abli' >Product page </Link></li>
                            <li>Grid Product</li>
                            <li>Full shop Page</li>
                        </ul>
                    </li>
                    <li className='Hmenu'>Pages<ChevronDown></ChevronDown>
                    <ul className='Hsmenu'>
                        <li><Link to ='/Terms' className='abli'>Terms & Conditions</Link></li>
                        <li>Privacy policy</li>
                        <li>FAQ</li>
                    </ul>
                    </li>
                    <li><Link to ='/Blog' className='abli'>Blog</Link></li>
                    <li><Link to ='/Contact' className='abli'>Contact</Link></li>
                </ul>


                <div className="sicon mt-3">

                    <p><Heart></Heart></p>
                    <br></br>
                    <p><Cart></Cart></p>
                    <p><Person></Person></p>
                    <p className='Hmenu'>Login/Register
                        <ul className='Hsmenu'>
                            <li><Link to='/Signin' className='abli' >Sign In </Link></li>
                            
                        </ul></p>

                </div>
            </div>
        </div>

    )
}