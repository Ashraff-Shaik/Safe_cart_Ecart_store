import about1 from '../../assets/images/about1.png';
import about2 from '../../assets/images/about2.png';
import about3 from '../../assets/images/about3.png';
import abcd1 from '../../assets/images/abcd1.png';
import abcd from '../../assets/images/abcd.png';
import abcd2 from '../../assets/images/abcd2.png';
import { BoxSeam, CalendarCheck, Truck, Wallet2 } from 'react-bootstrap-icons';
import './about.components.css';
import { Navbar } from '../navbar/navbar.components';
import { Navbar1 } from '../navbar1/navbar1.components';
import { U_menu } from '../u_menu/u_menu.components';
import { Footer } from '../footer/footer.components';


export function About() {
    return (
        <div>
            <Navbar></Navbar>
            <Navbar1></Navbar1>
            <U_menu></U_menu>
            <div  >
                <h2 style={{backgroundColor:'lightgray', padding:'3rem'}}>About</h2>
               
            </div>
            <div className="ab">
                <div className="container row mt-5 Aboutrw1">
                    <div className="col-6 Aboutrwp1">
                        <h2 className='para1'>This is how we do. Learn something about us and our services</h2>
                        <p>There’s a voice that keeps on calling me. Down the road, that’s where I’ll always be. Every stop I make, I make a new friend. Can’t stay for long, just turn around and I’m gone again. Maybe tomorrow, I’ll want to settle down, Until tomorrow, I’ll just keep moving on.
                            <br></br>Top Cat! The most effectual Top Cat! Who’s intellectual close friends get to call him T.C., providing it’s with dignity.</p>
                    </div>
                    <div className="col-6 ">
                        <img className='Aboutimg' src={about1}></img>
                    </div>
                </div>
                <div>
                    <br></br>
                    <br></br>
                    <br></br>
                </div>
                <div className="container row mt-5 Aboutrw2">
                    <div className="col-6">
                        <img className='Aboutimg' src={about2}></img>
                    </div>
                    <div className="col-6 Aboutrwp2">
                        <br></br>
                        <br></br>
                        <br></br>
                        <h2>We Provide Express & secure home delivery</h2>
                        <p>There’s a voice that keeps on calling me. Down the road, that’s where I’ll always be. Every stop I make, I make a new friend. Can’t stay for long, just turn around and I’m gone again. Maybe tomorrow, I’ll want to settle down, Until tomorrow, I’ll just keep moving on.
                            <br></br>
                            Top Cat! The most effectual Top Cat! Who’s intellectual close friends get to call him T.C., providing it’s with dignity.</p>
                    </div>
                </div>
                <div>
                    <br></br>
                    <br></br>
                    <br></br>
                </div>
                <div className="container row mt-5  ">
                    <div className="col-lg-6 ">
                        <h1>Our Advantages</h1>
                        <div className='row mt-5'>
                            <div className='col-6 ab1'>

                                <span className='abic m-2'>
                                    <Truck></Truck>
                                </span>
                                <div className='ab1d mt-4 ab1d'>
                                    <h6>Free Shipping</h6>
                                    <p>Free shipping on all online order</p>
                                </div>
                            </div>
                            <div className='col-6 ab1'>
                                <span className='abic m-2'>
                                    <Wallet2></Wallet2>
                                </span>
                                <div className='mt-4 ab1d'>
                                    <h6>100% Secure Payments</h6>
                                    <p>We insure secure transactions</p>
                                </div>
                            </div>
                        </div>
                        <div className='row mt-5'>
                            <div className='col-6 ab1'>

                                <span className='abic m-2'>
                                    <BoxSeam></BoxSeam>
                                </span>
                                <div className='mt-4 ab1d'>
                                    <h6>Fresh Product</h6>
                                    <p>We provide 100% Original item</p>
                                </div>
                            </div>
                            <div className='col-6 ab1'>
                                <span className='abic m-2'>
                                    <CalendarCheck></CalendarCheck>
                                </span>
                                <div className='mt-4 ab1d'>
                                    <h6>24/7 Support Center</h6>
                                    <p>We are available in 24 hours</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div className='col-6'>
                        <img className='Aboutimg' src={about3}></img>
                    </div>
                </div>

                <div className='container mt-5'>
                    <h2>Client Says</h2>
                    <div className='aboutcard'>
                        <div className='card col-lg-3 col-md-4 col-sm-6 mt-5'>
                            <div className='card abcard  para'>
                                <p className='mt-3 '> A group of sentences or a single sentence that forms a unit” (Lunsford and Connors 116). in some styles of writing, particularly journalistic styles</p>
                                <br></br>
                            </div>
                            <div  className='abcd1'>
                            <img  src={abcd1}></img>
                            </div>
                            <div className='mt-5 para'>
                                <br></br>
                                <h6>Harry Ferguson</h6>
                                <p>Student, Oxford University</p>
                            </div>
                        </div>
                        <div className='card col-lg-3 col-md-2 col-sm-6 mt-5'>
                            <div className='card abcard  para'>
                                <p className='mt-3 '> A group of sentences or a single sentence that forms a unit” (Lunsford and Connors 116). in some styles of writing, particularly journalistic styles</p>
                                <br></br>
                            </div>
                            <img className='abcd1' src={abcd}></img>
                            <div className='mt-5 para'>
                                <br></br>
                                <h6>Graham Ortega</h6>
                                <p>Student, Oxford University</p>
                            </div>

                        </div>
                        <div className='card col-lg-3 col-md-2 col-sm-6 mt-5'>
                            <div className='card abcard  para'>
                                <p className='mt-3 '> A group of sentences or a single sentence that forms a unit” (Lunsford and Connors 116). in some styles of writing, particularly journalistic styles</p>
                                <br></br>
                            </div>
                            <img className='abcd1' src={abcd2}></img>
                            <div className='mt-5 para'>
                                <br></br>
                                <h6>Melinda Watson</h6>
                                <p>Student, Oxford University</p>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <Footer></Footer>
        </div >
    )
}